# MLP_time_series
Multilayer Perceptron Approaches for time series data. Univariated and Multivariated. Based on Keras API: https://machinelearningmastery.com/keras-functional-api-deep-learning/
